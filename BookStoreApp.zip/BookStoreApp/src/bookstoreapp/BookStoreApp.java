//https://www.w3schools.com/java/java_arrays.asp
//https://www.youtube.com/watch?v=8mJ-OhcfpYg

//Title: Insertion Sort Algorithm
//Author:Rajat Mishra
//Date: 28 june 2024
//Version: 1
//Availabilty:geeksforgeeks.org/insertion-sort-algorithm/ 


package bookstoreapp;
import java.util.Scanner; //import scanner for the user prompts

public class BookStoreApp {

    public static void main(String[] args) {
    Scanner myScanner = new Scanner(System.in);
    String[] arr = {"Harry Potter", "The Great Gatsby", "To Kill a Mockingbird", "Pride and Prejudice", "Othello"}; // Array list with the books
       

    System.out.println("Pick a sorting method (type: ascending/descending): "); //prompt user with question
    String sort = myScanner.nextLine();
        
    if (sort.equals("ascending")) {
    insertionSortAscending(arr);//Call the method
    
    } else if (sort.equals("descending")) {
    insertionSortDescending(arr);
    
    } else {
    System.out.println("Invalid sorting method selected.");
    return;
    }

    System.out.println("Sorted books:");
    for (String book : arr) {
    System.out.println(book); //prints books in sorted order depeding on the prompt 
        }
    }

    private static void insertionSortAscending(String[] arr) {
    for (int i = 1; i < arr.length; ++i) { //This is the Outer loop that starts from the second element( index 1)
    String key = arr[i]; //Key is the element currently being inserted
    int j = i - 1; // j is the index of the last element in the sorted
    while (j >= 0 && arr[j].compareTo(key) > 0) { //Inner Loop (Shifting of Elements) Ascending
    arr[j + 1] = arr[j]; //Element is shifted one portion to the right
    j = j - 1; } //Decrement to check the previous element in the next iteration
    arr[j + 1] = key; //After the loop , key is placed in its correct position
        }
    }

    private static void insertionSortDescending(String[] arr) {
    for (int i = 1; i < arr.length; ++i) {
    String key = arr[i];
    int j = i - 1; 
    while (j >= 0 && arr[j].compareTo(key) < 0) { //Inner Loop (Shifting of Elements) Descending 
    arr[j + 1] = arr[j];
    j = j - 1; } 
    arr[j + 1] = key; 
        }
    }
}

